import React from 'react';
import { Github, Linkedin, Mail, Heart, Instagram } from 'lucide-react';
import { PERSONAL_INFO } from '../constants';

export const Footer: React.FC = () => {
  return (
    <footer className="bg-gray-50 dark:bg-black/30 pt-10 pb-8 border-t border-gray-200 dark:border-gray-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row justify-between items-center gap-6">
          
          {/* Brand */}
          <div className="text-center md:text-left">
            <h3 className="font-mono text-lg font-bold text-slate-900 dark:text-white">
              &lt;{PERSONAL_INFO.name.split(' ')[0]} /&gt;
            </h3>
            <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">
              Building the future with AI & Automation.
            </p>
          </div>

          {/* Social Icons */}
          <div className="flex space-x-4">
            <a href={PERSONAL_INFO.socials.github} target="_blank" rel="noreferrer" className="p-2 bg-white dark:bg-gray-800 rounded-full text-gray-600 dark:text-gray-400 hover:text-brand-500 dark:hover:text-brand-400 shadow-sm transition-colors">
              <Github size={18} />
            </a>
            <a href={PERSONAL_INFO.socials.linkedin} target="_blank" rel="noreferrer" className="p-2 bg-white dark:bg-gray-800 rounded-full text-gray-600 dark:text-gray-400 hover:text-brand-500 dark:hover:text-brand-400 shadow-sm transition-colors">
              <Linkedin size={18} />
            </a>
            <a href={PERSONAL_INFO.socials.instagram} target="_blank" rel="noreferrer" className="p-2 bg-white dark:bg-gray-800 rounded-full text-gray-600 dark:text-gray-400 hover:text-brand-500 dark:hover:text-brand-400 shadow-sm transition-colors">
              <Instagram size={18} />
            </a>
            <a href={`mailto:${PERSONAL_INFO.socials.email}`} className="p-2 bg-white dark:bg-gray-800 rounded-full text-gray-600 dark:text-gray-400 hover:text-brand-500 dark:hover:text-brand-400 shadow-sm transition-colors">
              <Mail size={18} />
            </a>
          </div>
        </div>

        <div className="mt-8 pt-8 border-t border-gray-200 dark:border-gray-800 flex flex-col md:flex-row justify-between items-center text-xs text-gray-500 dark:text-gray-500">
          <p>© {new Date().getFullYear()} {PERSONAL_INFO.name}. All rights reserved.</p>
          <p className="flex items-center mt-2 md:mt-0">
            Based in {PERSONAL_INFO.location} <span className="mx-2">•</span> 
            Made with <Heart size={10} className="mx-1 text-red-500 fill-current" />
          </p>
        </div>
      </div>
    </footer>
  );
};