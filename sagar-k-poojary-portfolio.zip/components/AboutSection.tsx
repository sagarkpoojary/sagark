import React from 'react';
import { motion } from 'framer-motion';
import { Mail, Phone, Github, Linkedin, Instagram, FileText } from 'lucide-react';
import { PERSONAL_INFO } from '../constants';

export const AboutSection: React.FC = () => {
  return (
    <section id="contact" className="py-20 bg-white dark:bg-dark-bg transition-colors relative">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-white dark:bg-dark-card rounded-2xl p-8 md:p-12 shadow-xl border border-gray-100 dark:border-gray-800">
          
          <div className="text-center mb-10">
            <h2 className="text-3xl font-bold text-slate-900 dark:text-white mb-4">Let's Connect</h2>
            <p className="text-gray-600 dark:text-gray-400">
              Open to opportunities in the UK Tech Market. <br/>
              Expertise in AI, Automation, and Full-Stack Engineering.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {/* Contact Details */}
            <div className="space-y-6">
              <h3 className="text-xl font-semibold text-slate-900 dark:text-white border-b border-gray-200 dark:border-gray-700 pb-2">
                Contact Information
              </h3>
              
              <a href={`mailto:${PERSONAL_INFO.socials.email}`} className="flex items-center space-x-4 p-4 rounded-lg bg-gray-50 dark:bg-black/20 hover:bg-brand-50 dark:hover:bg-brand-900/20 transition-colors group">
                <div className="p-3 bg-white dark:bg-dark-bg rounded-full shadow-sm text-brand-500 group-hover:text-brand-600">
                  <Mail size={20} />
                </div>
                <div>
                  <p className="text-xs text-gray-500 uppercase tracking-wide">Email</p>
                  <p className="text-slate-900 dark:text-slate-200 font-medium">{PERSONAL_INFO.socials.email}</p>
                </div>
              </a>

              <a href={`tel:${PERSONAL_INFO.socials.phone}`} className="flex items-center space-x-4 p-4 rounded-lg bg-gray-50 dark:bg-black/20 hover:bg-brand-50 dark:hover:bg-brand-900/20 transition-colors group">
                <div className="p-3 bg-white dark:bg-dark-bg rounded-full shadow-sm text-brand-500 group-hover:text-brand-600">
                  <Phone size={20} />
                </div>
                <div>
                  <p className="text-xs text-gray-500 uppercase tracking-wide">Phone</p>
                  <p className="text-slate-900 dark:text-slate-200 font-medium">{PERSONAL_INFO.socials.phone}</p>
                </div>
              </a>
            </div>

            {/* Social Profiles */}
            <div className="space-y-6">
              <h3 className="text-xl font-semibold text-slate-900 dark:text-white border-b border-gray-200 dark:border-gray-700 pb-2">
                Social Profiles
              </h3>
              
              <div className="grid grid-cols-1 gap-4">
                <a 
                  href={PERSONAL_INFO.socials.github}
                  target="_blank"
                  rel="noreferrer"
                  className="flex items-center justify-between p-4 rounded-lg border border-gray-200 dark:border-gray-700 hover:border-brand-500 dark:hover:border-brand-500 hover:shadow-md transition-all group"
                >
                  <span className="flex items-center text-slate-700 dark:text-slate-300 group-hover:text-brand-600 dark:group-hover:text-brand-400">
                    <Github size={20} className="mr-3" />
                    GitHub
                  </span>
                  <span className="text-xs text-gray-400">13+ Repos</span>
                </a>

                <a 
                  href={PERSONAL_INFO.socials.linkedin}
                  target="_blank"
                  rel="noreferrer"
                  className="flex items-center justify-between p-4 rounded-lg border border-gray-200 dark:border-gray-700 hover:border-brand-500 dark:hover:border-brand-500 hover:shadow-md transition-all group"
                >
                  <span className="flex items-center text-slate-700 dark:text-slate-300 group-hover:text-brand-600 dark:group-hover:text-brand-400">
                    <Linkedin size={20} className="mr-3" />
                    LinkedIn
                  </span>
                  <span className="text-xs text-gray-400">Connect</span>
                </a>

                <a 
                  href={PERSONAL_INFO.socials.instagram}
                  target="_blank"
                  rel="noreferrer"
                  className="flex items-center justify-between p-4 rounded-lg border border-gray-200 dark:border-gray-700 hover:border-brand-500 dark:hover:border-brand-500 hover:shadow-md transition-all group"
                >
                  <span className="flex items-center text-slate-700 dark:text-slate-300 group-hover:text-brand-600 dark:group-hover:text-brand-400">
                    <Instagram size={20} className="mr-3" />
                    Instagram
                  </span>
                  <span className="text-xs text-gray-400">Follow</span>
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};