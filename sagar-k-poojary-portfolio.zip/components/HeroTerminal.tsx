import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Terminal, Shield, Bot, Workflow } from 'lucide-react';
import { PERSONAL_INFO } from '../constants';

const TYPING_STRINGS = [
  "MLOps & AI Engineer",
  "Automation Architect (n8n)",
  "Full-Stack TypeScript Dev",
  "Systems Security Analyst"
];

export const HeroTerminal: React.FC = () => {
  const [textIndex, setTextIndex] = useState(0);
  const [charIndex, setCharIndex] = useState(0);
  const [isDeleting, setIsDeleting] = useState(false);
  const [displayText, setDisplayText] = useState("");

  useEffect(() => {
    const currentString = TYPING_STRINGS[textIndex];
    const typingSpeed = isDeleting ? 40 : 80;
    const pauseTime = 2000;

    const type = () => {
      if (!isDeleting && charIndex < currentString.length) {
        // Typing
        setDisplayText(currentString.substring(0, charIndex + 1));
        setCharIndex(charIndex + 1);
      } else if (isDeleting && charIndex > 0) {
        // Deleting
        setDisplayText(currentString.substring(0, charIndex - 1));
        setCharIndex(charIndex - 1);
      } else if (!isDeleting && charIndex === currentString.length) {
        // Finished typing, wait before delete
        setTimeout(() => setIsDeleting(true), pauseTime);
        return;
      } else if (isDeleting && charIndex === 0) {
        // Finished deleting, move to next string
        setIsDeleting(false);
        setTextIndex((prev) => (prev + 1) % TYPING_STRINGS.length);
      }
    };

    const timer = setTimeout(type, typingSpeed);
    return () => clearTimeout(timer);
  }, [charIndex, isDeleting, textIndex]);

  return (
    <section id="about" className="relative min-h-screen flex items-center justify-center pt-20 pb-10">
      <div className="container mx-auto px-4 z-10">
        <div className="flex flex-col items-center">
          
          {/* Terminal Window */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, ease: "easeOut" }}
            className="w-full max-w-4xl bg-slate-900/90 backdrop-blur-xl rounded-xl shadow-2xl overflow-hidden border border-slate-700/50"
          >
            {/* Terminal Header */}
            <div className="bg-slate-800/80 px-4 py-3 flex items-center justify-between border-b border-slate-700">
              <div className="flex gap-2">
                <div className="w-3 h-3 rounded-full bg-red-500/80" />
                <div className="w-3 h-3 rounded-full bg-yellow-500/80" />
                <div className="w-3 h-3 rounded-full bg-green-500/80" />
              </div>
              <div className="flex items-center text-xs text-slate-400 font-mono">
                <Terminal size={12} className="mr-2" />
                sagar_poojary@uk-dev — ~
              </div>
              <div className="w-10"></div>
            </div>

            {/* Terminal Content */}
            <div className="p-6 md:p-12 font-mono text-sm md:text-base text-slate-300 min-h-[380px] flex flex-col justify-center">
              
              <div className="mb-6 space-y-2">
                <div className="flex flex-wrap">
                  <span className="text-green-400 font-bold">➜</span>
                  <span className="text-blue-400 ml-2 font-bold">~</span>
                  <span className="text-slate-400 ml-2">./initialize_profile.sh --role=automation_architect</span>
                </div>
              </div>
              
              <h1 className="text-4xl md:text-6xl font-bold text-white mb-4 tracking-tight">
                {PERSONAL_INFO.name}
              </h1>
              
              <div className="text-xl md:text-2xl text-brand-400 font-semibold h-8 flex items-center mb-6">
                <span className="mr-2">&gt;</span>
                <span>{displayText}</span>
                <span className="animate-pulse ml-1 inline-block w-2 h-6 bg-brand-400 align-middle"></span>
              </div>

              <div className="mt-4 text-slate-400 max-w-2xl leading-relaxed text-base md:text-lg border-l-2 border-slate-700 pl-4">
                <p>
                  {PERSONAL_INFO.tagline} <br/>
                  Specializing in operational efficiency through self-hosted n8n workflows, Python MLOps pipelines, and secure cloud architecture.
                </p>
              </div>

              {/* Status Indicators */}
              <div className="mt-10 grid grid-cols-2 md:grid-cols-3 gap-4">
                <div className="flex items-center gap-2 text-xs text-slate-500">
                  <Shield size={14} className="text-green-500" />
                  <span>Security: Hardened</span>
                </div>
                <div className="flex items-center gap-2 text-xs text-slate-500">
                  <Workflow size={14} className="text-blue-500" />
                  <span>Workflows: Automated</span>
                </div>
                <div className="flex items-center gap-2 text-xs text-slate-500">
                  <Bot size={14} className="text-purple-500" />
                  <span>AI Agents: Active</span>
                </div>
              </div>

              <div className="mt-10 flex gap-4">
                <a 
                  href="#projects"
                  className="bg-brand-600 hover:bg-brand-500 text-white px-6 py-3 rounded-lg font-medium transition-all hover:shadow-[0_0_20px_rgba(14,165,233,0.3)]"
                >
                  View Work
                </a>
                <a 
                  href="#contact"
                  className="border border-slate-600 hover:border-slate-400 text-slate-300 hover:text-white px-6 py-3 rounded-lg font-medium transition-colors"
                >
                  Contact Info
                </a>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
};