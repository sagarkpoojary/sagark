import React from 'react';
import { motion } from 'framer-motion';
import { SKILLS } from '../constants';
import { Zap } from 'lucide-react';

const fadeInAnimationVariants = {
  initial: { opacity: 0, y: 20 },
  animate: (index: number) => ({
    opacity: 1,
    y: 0,
    transition: {
      delay: 0.05 * index,
    },
  }),
};

const CATEGORY_INFO = {
  'ai-automation': {
    title: 'AI & Automation Stack',
    subtitle: 'The Core Focus',
    description: 'High-value skills in workflow automation, MLOps, and intelligent self-hosted systems.'
  },
  'backend-infra': {
    title: 'Backend & Infrastructure',
    subtitle: 'Robust & Scalable',
    description: 'Building modern server-side applications with Flask, Docker, and Cloud Serverless tech.'
  },
  'frontend-ux': {
    title: 'Frontend & UX',
    subtitle: 'Performant & Interactive',
    description: 'Creating high-quality interfaces with TypeScript, React, and motion-rich interactions.'
  }
};

export const SkillsCloud: React.FC = () => {
  const categories = Object.keys(CATEGORY_INFO) as Array<keyof typeof CATEGORY_INFO>;

  return (
    <section id="skills" className="py-24 bg-gray-50 dark:bg-dark-bg/50 transition-colors">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-slate-900 dark:text-white mb-4">
            Technical Arsenal
          </h2>
          <div className="w-16 h-1 bg-brand-500 mx-auto rounded"></div>
          <p className="mt-4 text-lg text-gray-600 dark:text-gray-400 max-w-2xl mx-auto">
             Leveraging the <span className="text-brand-600 dark:text-brand-400 font-semibold">latest trending</span> technologies to build scalable, secure, and automated solutions.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {categories.map((category, catIndex) => (
                <div key={category} className="bg-white dark:bg-dark-card p-8 rounded-2xl shadow-sm border border-gray-100 dark:border-gray-800 flex flex-col">
                    <div className="mb-6">
                        <span className="text-xs font-bold tracking-wider text-brand-500 uppercase mb-1 block">
                            {CATEGORY_INFO[category].subtitle}
                        </span>
                        <h3 className="text-2xl font-bold text-slate-900 dark:text-white mb-3">
                            {CATEGORY_INFO[category].title}
                        </h3>
                        <p className="text-sm text-gray-600 dark:text-gray-400 leading-relaxed">
                            {CATEGORY_INFO[category].description}
                        </p>
                    </div>
                    
                    <div className="flex flex-wrap gap-2 mt-auto">
                        {SKILLS.filter(s => s.category === category).map((skill, index) => (
                            <motion.div
                                key={skill.name}
                                variants={fadeInAnimationVariants}
                                initial="initial"
                                whileInView="animate"
                                viewport={{ once: true }}
                                custom={index}
                                className={`
                                    relative group px-4 py-2 rounded-lg text-sm font-medium border transition-all cursor-default
                                    ${skill.highlight 
                                        ? 'bg-brand-50 dark:bg-brand-900/20 border-brand-200 dark:border-brand-800 text-brand-700 dark:text-brand-300' 
                                        : 'bg-gray-50 dark:bg-gray-800/50 border-gray-200 dark:border-gray-700 text-gray-700 dark:text-gray-300 hover:border-gray-300 dark:hover:border-gray-600'
                                    }
                                `}
                            >
                                {skill.name}
                                {skill.highlight && (
                                    <div className="absolute -top-1 -right-1">
                                        <span className="flex h-2 w-2">
                                          <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-brand-400 opacity-75"></span>
                                          <span className="relative inline-flex rounded-full h-2 w-2 bg-brand-500"></span>
                                        </span>
                                    </div>
                                )}
                            </motion.div>
                        ))}
                    </div>
                </div>
            ))}
        </div>
      </div>
    </section>
  );
};