import React, { useRef } from 'react';
import { motion, useMotionTemplate, useMotionValue, useSpring } from 'framer-motion';
import { Github, ExternalLink } from 'lucide-react';
import { PROJECTS } from '../constants';
import { Project } from '../types';

const ROTATION_RANGE = 15;
const HALF_ROTATION_RANGE = 15 / 2;

const TiltCard: React.FC<{ project: Project; index: number }> = ({ project, index }) => {
  const ref = useRef<HTMLDivElement>(null);

  const x = useMotionValue(0);
  const y = useMotionValue(0);

  const xSpring = useSpring(x);
  const ySpring = useSpring(y);

  const transform = useMotionTemplate`rotateX(${xSpring}deg) rotateY(${ySpring}deg)`;

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement, MouseEvent>) => {
    if (!ref.current) return;

    const rect = ref.current.getBoundingClientRect();

    const width = rect.width;
    const height = rect.height;

    const mouseX = (e.clientX - rect.left) * ROTATION_RANGE;
    const mouseY = (e.clientY - rect.top) * ROTATION_RANGE;

    const rX = (mouseY / height - HALF_ROTATION_RANGE) * -1;
    const rY = mouseX / width - HALF_ROTATION_RANGE;

    x.set(rX);
    y.set(rY);
  };

  const handleMouseLeave = () => {
    x.set(0);
    y.set(0);
  };

  const hasLiveUrl = project.liveUrl && project.liveUrl !== '#';

  return (
    <motion.div
      ref={ref}
      onMouseMove={handleMouseMove}
      onMouseLeave={handleMouseLeave}
      initial={{ opacity: 0, y: 50 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-50px" }}
      transition={{ duration: 0.5, delay: index * 0.1 }}
      style={{
        transformStyle: "preserve-3d",
        transform
      }}
      className="relative h-full rounded-xl bg-white dark:bg-dark-card border border-gray-100 dark:border-gray-800 shadow-xl group"
    >
      <div 
        style={{ transform: "translateZ(50px)" }} 
        className="absolute inset-4 z-10 pointer-events-none"
      >
        {/* Floating elements can go here */}
      </div>

      <div className="h-full flex flex-col overflow-hidden rounded-xl">
        {/* Image Area */}
        <div className="relative h-48 overflow-hidden">
          <img 
            src={project.image} 
            alt={project.title} 
            className="w-full h-full object-cover transition-transform duration-500 hover:scale-110"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent" />
          
          <div className="absolute bottom-4 left-4 right-4 flex justify-between items-end">
             <div className="flex gap-2">
                {project.githubUrl && (
                  <a 
                    href={project.githubUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="p-2 bg-white/20 backdrop-blur-md rounded-lg text-white hover:bg-white/40 transition-colors pointer-events-auto"
                    onClick={(e) => e.stopPropagation()}
                    aria-label="View Source on GitHub"
                  >
                    <Github size={18} />
                  </a>
                )}
                
                {hasLiveUrl && (
                  <a 
                    href={project.liveUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="p-2 bg-brand-500/80 backdrop-blur-md rounded-lg text-white hover:bg-brand-500 transition-colors pointer-events-auto"
                    onClick={(e) => e.stopPropagation()}
                    aria-label="View Live Demo"
                  >
                    <ExternalLink size={18} />
                  </a>
                )}
             </div>
          </div>
        </div>

        {/* Content Area */}
        <div className="p-6 flex flex-col flex-grow bg-white dark:bg-dark-card">
          <h3 className="text-xl font-bold text-slate-900 dark:text-white mb-2 flex items-center">
            {project.title}
          </h3>
          
          <p className="text-gray-600 dark:text-gray-400 text-sm mb-6 flex-grow leading-relaxed">
            {project.description}
          </p>
          
          <div className="flex flex-wrap gap-2 mt-auto">
            {project.tags.map((tag: string) => (
              <span 
                key={tag}
                className="px-2 py-1 text-[10px] uppercase tracking-wider font-bold rounded bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 border border-slate-200 dark:border-slate-700"
              >
                {tag}
              </span>
            ))}
          </div>
        </div>
      </div>
    </motion.div>
  );
};

export const ProjectsGrid: React.FC = () => {
  return (
    <section id="projects" className="py-24 relative overflow-hidden">
      <div className="absolute top-0 left-0 w-full h-px bg-gradient-to-r from-transparent via-brand-500/50 to-transparent" />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="text-center mb-20">
          <h2 className="text-3xl md:text-5xl font-bold text-slate-900 dark:text-white mb-6 tracking-tight">
            Selected Work
          </h2>
          <p className="text-lg text-gray-600 dark:text-gray-400 max-w-2xl mx-auto">
            Showcasing expertise in Cloud Architecture, Machine Learning pipelines, and Secure Systems integration.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-2 gap-8 lg:gap-12 max-w-5xl mx-auto">
          {PROJECTS.map((project, index) => (
            <TiltCard key={project.id} project={project} index={index} />
          ))}
        </div>
      </div>
    </section>
  );
};